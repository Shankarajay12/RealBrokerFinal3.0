package com.realestate.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.realestate.entity.Cart;
@Repository
public interface CartDao extends JpaRepository<Cart, Integer> {

}
