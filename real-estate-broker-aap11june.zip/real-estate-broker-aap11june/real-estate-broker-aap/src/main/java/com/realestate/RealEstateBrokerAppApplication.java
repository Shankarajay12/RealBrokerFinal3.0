package com.realestate;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.io.File;
import com.realestate.web.controller.ImageController;

@SpringBootApplication
public class RealEstateBrokerAppApplication {

	public static void main(String[] args) {
		new File(ImageController.uploadDirectory).mkdir();
		SpringApplication.run(RealEstateBrokerAppApplication.class, args);
	}

}
