package com.realestate.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.realestate.entity.Property;
@Repository
public interface PropertyDao extends JpaRepository<Property, Integer> {
	
	
	
	@Query(value = "SELECT * FROM PROPERTY WHERE property_city=?1", nativeQuery = true)
	List<Property> getAllByCity(String city);
	
	@Query(value = "SELECT * FROM PROPERTY WHERE property_state=?1", nativeQuery = true)
	List<Property> getAllByState(String state);

}
