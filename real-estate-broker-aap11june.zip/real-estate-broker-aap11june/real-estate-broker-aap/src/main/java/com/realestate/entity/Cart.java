package com.realestate.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cartId;
	private int cartPropertyId=0;
	private int cartPropertyPrice;
	private String cartPropertyTitle;
	private String cartPropertyDescription;
	private String cartPropertyType;
	private String cartPropertyArea;
	private String cartPropertyCity;
	private String cartPropertyState;
	private String cartPath;
}