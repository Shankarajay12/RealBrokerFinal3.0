package com.realestate.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.realestate.dao.AdminDao;
import com.realestate.dao.UserDao;
import com.realestate.entity.Admin;
import com.realestate.entity.User;

@Service
public class AdminService {
	@Autowired
	private AdminDao adminDao;
	public Optional<Admin> getAdmin(int id) {
		Optional<Admin> admin=null;
		try {
			admin=this.adminDao.findById(id);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return admin;
	}
	public List<Admin> getAllAdmins(){
		return this.adminDao.findAll();
	}
	public Admin setAdmin(Admin a) {
		return this.adminDao.save(a);
	}
	public Admin findAdminByEmail(String AdminEmail)
	{
		Admin admin=adminDao.findByAdminEmail(AdminEmail);
		return admin;
	}
	public void deleteAdmin(int id){
		this.adminDao.deleteById(id);
	}
	public Admin updateAdmin(Admin a,int id) {
		Optional<Admin> optional=this.adminDao.findById(id);
		Admin admin=optional.get();
		a.setAdminName(admin.getAdminName());
		a.setAdminEmail(admin.getAdminEmail());
		a.setAdminPassword(admin.getAdminPassword());
		a.setAdminCity(admin.getAdminCity());
		a.setAdminState(admin.getAdminState());
		return a;
	}
	
}
